<div style="

        background-color: #b2c3ce;
        padding: 50px;
        width: 100%;
        box-sizing: border-box;
        "  class="d-flex justify-content-center align-items-center ">
    <div class="main_container" style="
            padding: 20px 20px;
            width: 450px;
            height: auto;
            background-color: #ffffff;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            box-shadow: 1px 1px 5px #ddd;
            ">
        <div class="business_details" style="

        "
        class="d-flex justify-content-center align-items-center flex-column ">
            <img style="
            width: 50px;
            height: 50px;
            object-fit: contain;
            " class="business_logo" src="https://i.ibb.co/M8YmF13/Porsche-logo-PNG2.png" alt="">
            <h2 class="business_title" style="
            color: #555555;
            ">Business Name</h2>
        </div>
        <hr style="border-color: #eeeeee;">
        <div class="action_container" style="

        margin-top: 10px;

        "
        class="d-flex justify-content-center align-items-center flex-column ">
            <p style="
            color: #555555;
            font-size: 19px;
            ">Invoice for <strong>&pound;10.00</strong> due by <strong>Jul 11,
                    2023</strong>
            </p>
            <a style="
            padding: 15px 50px;
            border-radius: 30px;
            background-color: #0575b4;
            color: #ffffff;
            font-size: 18px;
            font-weight: bold;
            border: none;

            ">View Invoice</a>
        </div>
        <div class="message_text" style="margin: 50px 0px;">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Officia aperiam earum temporibus, debitis
            nesciunt repudiandae eos vel ad accusamus dicta voluptatibus cumque dolore velit error consequuntur.
            Vitae earum laudantium quis?
        </div>

        <div class="footer_container">
            <small style="
                text-align: center;
                display: block;
                ">Invoice 17</small>
            <small class="company_name" style="
            display: block;
            text-align: center;
            font-weight: bold;
            color: #999;
            ">
                Business Name
            </small>
        </div>
    </div>
</div>
