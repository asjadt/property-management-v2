<?php

namespace App\Http\Controllers;

use App\Http\Utils\ErrorUtil;
use App\Http\Utils\UserActivityUtil;
use App\Models\Invoice;
use App\Models\Property;
use App\Models\Receipt;
use App\Models\Repair;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PropertyBasicController extends Controller
{
use ErrorUtil,UserActivityUtil;

/**
 *
 * @OA\Get(
 *      path="/v1.0/activities/{perPage}",
 *      operationId="showActivity",
 *      tags={"property_management.basics"},
 *       security={
 *           {"bearerAuth": {}}
 *       },

 *              @OA\Parameter(
 *         name="perPage",
 *         in="path",
 *         description="perPage",
 *         required=true,
 *  example="6"
 *      ),
 *      * *  @OA\Parameter(
* name="start_date",
* in="query",
* description="start_date",
* required=true,
* example="2019-06-29"
* ),
 * *  @OA\Parameter(
* name="end_date",
* in="query",
* description="end_date",
* required=true,
* example="2019-06-29"
* ),
 * *  @OA\Parameter(
* name="search_key",
* in="query",
* description="search_key",
* required=true,
* example="search_key"
* ),
 * *  @OA\Parameter(
* name="property_id",
* in="query",
* description="property_id",
* required=true,
* example="property_id"
* ),
 * *  @OA\Parameter(
* name="tenant_id",
* in="query",
* description="tenant_id",
* required=true,
* example="tenant_id"
* ),
 * *  @OA\Parameter(
* name="landlord_id",
* in="query",
* description="landlord_id",
* required=true,
* example="landlord_id"
* ),
 *      summary="This method is to get activities ",
 *      description="This method is to get activities",
 *

 *      @OA\Response(
 *          response=200,
 *          description="Successful operation",
 *       @OA\JsonContent(),
 *       ),
 *      @OA\Response(
 *          response=401,
 *          description="Unauthenticated",
 * @OA\JsonContent(),
 *      ),
 *        @OA\Response(
 *          response=422,
 *          description="Unprocesseble Content",
 *    @OA\JsonContent(),
 *      ),
 *      @OA\Response(
 *          response=403,
 *          description="Forbidden",
 *   @OA\JsonContent()
 * ),
 *  * @OA\Response(
 *      response=400,
 *      description="Bad Request",
 *   *@OA\JsonContent()
 *   ),
 * @OA\Response(
 *      response=404,
 *      description="not found",
 *   *@OA\JsonContent()
 *   )
 *      )
 *     )
 */

 public function showActivity($perPage, Request $request)
 {
     try {
         $this->storeActivity($request,"");




        //  $propertyQuery =  Property::where(["created_by" => $request->user()->id]);

        //  if (!empty($request->search_key)) {
        //      $propertyQuery = $propertyQuery->where(function ($query) use ($request) {
        //          $term = $request->search_key;
        //          $query->where("name", "like", "%" . $term . "%");
        //          $query->orWhere("address", "like", "%" . $term . "%");
        //      });
        //  }

        //  if (!empty($request->address)) {
        //      $propertyQuery =  $propertyQuery->orWhere("address", "like", "%" . $request->address . "%");
        //  }

        //  if (!empty($request->start_date)) {
        //      $propertyQuery = $propertyQuery->where('created_at', ">=", $request->start_date);
        //  }
        //  if (!empty($request->end_date)) {
        //      $propertyQuery = $propertyQuery->where('created_at', "<=", $request->end_date);
        //  }

        //  $properties = $propertyQuery->orderByDesc("id")->paginate($perPage);


        if(!empty($request->property_id)) {
            $property = Property::where([
                "id" => $request->property_id
            ])
            ->first();
            if(!$property) {
                  return response()->json([
                    "message" => "no property found"
                  ],404);
            }
            $repairQuery = Repair::where([
                "repairs.property_id" => $property->id
            ])
            ->when(!empty($request->start_date), function ($query) use ($request) {
                return $query->where('repairs.created_at', ">=", $request->start_date);
            })
            ->when(!empty($request->end_date), function ($query) use ($request) {
                return $query->where('repairs.created_at', "<=", $request->end_date);
            })
            ->select('repairs.price', 'repairs.created_at', DB::raw("'repair' as type"));

            $invoiceQuery = Invoice::where([
                "invoices.property_id" => $property->id
            ])
            ->when(!empty($request->start_date), function ($query) use ($request) {
                return $query->where('invoices.created_at', ">=", $request->start_date);
            })
            ->when(!empty($request->end_date), function ($query) use ($request) {
                return $query->where('invoices.created_at', "<=", $request->end_date);
            })
            ->select('invoices.total_amount', 'invoices.created_at', DB::raw("'invoice' as type"));


            $receiptQuery = Receipt::where([
                "receipts.property_address" => $property->address
            ])
            ->when(!empty($request->start_date), function ($query) use ($request) {
                return $query->where('receipts.created_at', ">=", $request->start_date);
            })
            ->when(!empty($request->end_date), function ($query) use ($request) {
                return $query->where('receipts.created_at', "<=", $request->end_date);
            })
            ->select('receipts.amount', 'receipts.created_at', DB::raw("'receipt' as type"));

            $activitiesQuery = $repairQuery
                ->unionAll($invoiceQuery)
                ->unionAll($receiptQuery)
                ->orderBy('created_at', 'asc');






        }
       else if(!empty($request->landlord_id)) {
            $landlord = Property::where([
                "id" => $request->landlord_id
            ])
            ->first();
            if(!$landlord) {
                  return response()->json([
                    "message" => "no landlord found"
                  ],404);
            }
            $activitiesQuery = Invoice::where([
                "invoices.landlord_id" => $landlord->id
            ])
                ->when(!empty($request->start_date), function ($query) use ($request) {
                    return $query->where('invoices.created_at', ">=", $request->start_date);
                })
                ->when(!empty($request->end_date), function ($query) use ($request) {
                    return $query->where('invoices.created_at', "<=", $request->end_date);
                })
                ->select('invoices.total_amount', 'invoices.created_at', DB::raw("'invoice' as type"));

            // $activitiesQuery = $activitiesQuery->unionAll(
            //     Invoice::where([
            //         "invoices.property_id" => $request->landlord_id
            //     ])
            //     ->when(!empty($request->start_date), function ($query) use ($request) {
            //         return $query->where('invoices.created_at', ">=", $request->start_date);
            //     })
            //     ->when(!empty($request->end_date), function ($query) use ($request) {
            //         return $query->where('invoices.created_at', "<=", $request->end_date);
            //     })
            //     ->select('invoices.*')
            // );



        }
        else if(!empty($request->tenant_id)) {
            $tenant = Property::where([
                "id" => $request->tenant_id
            ])
            ->first();
            if(!$tenant) {
                  return response()->json([
                    "message" => "no tenant found"
                  ],404);
            }
            $invoiceQuery = Invoice::where([
                "invoices.tenant_id" => $tenant->id
            ])
            ->when(!empty($request->start_date), function ($query) use ($request) {
                return $query->where('invoices.created_at', ">=", $request->start_date);
            })
            ->when(!empty($request->end_date), function ($query) use ($request) {
                return $query->where('invoices.created_at', "<=", $request->end_date);
            })
            ->select('invoices.total_amount', 'invoices.created_at', DB::raw("'invoice' as type"));

            $receiptQuery = Receipt::where([
                "receipts.tenant_id" => $tenant->id
            ])
            ->when(!empty($request->start_date), function ($query) use ($request) {
                return $query->where('receipts.created_at', ">=", $request->start_date);
            })
            ->when(!empty($request->end_date), function ($query) use ($request) {
                return $query->where('receipts.created_at', "<=", $request->end_date);
            })
            ->select('receipts.amount', 'receipts.created_at', DB::raw("'receipt' as type"));

            $activitiesQuery = $invoiceQuery->unionAll($receiptQuery)
                ->orderBy('created_at', 'asc');



        }

        else {
            $error =  [
                "message" => "The given data was invalid.",
                "errors" => [
                    "property_id"=>["property must be selected if landlord or tenant is not selected."],
                    "tenant_id"=>["tenant must be selected if landlord or property is not selected."],
                    "landlord_id"=>["landlord must be selected if tenant or property is not selected."]
                    ]
         ];
            throw new Exception(json_encode($error),422);
        }


        $activitiesPaginated = $activitiesQuery->paginate($perPage);
        return response()->json($activitiesPaginated, 200);


     } catch (Exception $e) {

         return $this->sendError($e, 500,$request);
     }
 }
}
