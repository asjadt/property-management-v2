<?php






namespace App\Http\Controllers;



use App\Http\Requests\AccreditationCreateRequest;
use App\Http\Requests\AccreditationUpdateRequest;
use App\Http\Requests\GetIdRequest;
use App\Http\Utils\BasicUtil;
use App\Http\Utils\BusinessUtil;
use App\Http\Utils\ErrorUtil;
use App\Http\Utils\UserActivityUtil;
use App\Models\Accreditation;
use App\Models\DisabledAccreditation;
use App\Models\User;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AccreditationController extends Controller
{

    use ErrorUtil, UserActivityUtil, BasicUtil;


    /**
     *
     * @OA\Post(
     * path="/v1.0/accreditations",
     * operationId="createAccreditation",
     * tags={"accreditations"},
     * security={
     * {"bearerAuth": {}}
     * },
     * summary="This method is to store accreditations",
     * description="This method is to store accreditations",
     *
     * @OA\RequestBody(
     * required=true,
     * @OA\JsonContent(
     * @OA\Property(property="name", type="string", format="string", example="name"),
     * @OA\Property(property="description", type="string", format="string", example="description"),
     * @OA\Property(property="accreditation_start_date", type="string", format="string", example="accreditation_start_date"),
     * @OA\Property(property="accreditation_expiry_date", type="string", format="string", example="accreditation_expiry_date"),
     * @OA\Property(property="logo", type="string", format="string", example="logo"),


     *
     *
     *
     * ),
     * ),
     * @OA\Response(
     * response=200,
     * description="Successful operation",
     * @OA\JsonContent(),
     * ),
     * @OA\Response(
     * response=401,
     * description="Unauthenticated",
     * @OA\JsonContent(),
     * ),
     * @OA\Response(
     * response=422,
     * description="Unprocesseble Content",
     * @OA\JsonContent(),
     * ),
     * @OA\Response(
     * response=403,
     * description="Forbidden",
     * @OA\JsonContent()
     * ),
     * * @OA\Response(
     * response=400,
     * description="Bad Request",
     * *@OA\JsonContent()
     * ),
     * @OA\Response(
     * response=404,
     * description="not found",
     * *@OA\JsonContent()
     * )
     * )
     * )
     */

    public function createAccreditation(AccreditationCreateRequest $request)
    {

        DB::beginTransaction();
        try {
            $this->storeActivity($request, "DUMMY activity", "DUMMY description");



            $request_data = $request->validated();

            $request_data["is_active"] = 1;

            $request_data["created_by"] = auth()->user()->id;



            $accreditation = Accreditation::create($request_data);



            DB::commit();
            return response($accreditation, 201);
        } catch (Exception $e) {
            DB::rollBack();
            return $this->sendError($e, 500, $request);
        }
    }
    /**
     *
     * @OA\Put(
     * path="/v1.0/accreditations",
     * operationId="updateAccreditation",
     * tags={"accreditations"},
     * security={
     * {"bearerAuth": {}}
     * },
     * summary="This method is to update accreditations ",
     * description="This method is to update accreditations ",
     *
     * @OA\RequestBody(
     * required=true,
     * @OA\JsonContent(
     * @OA\Property(property="id", type="number", format="number", example="1"),
     * @OA\Property(property="name", type="string", format="string", example="name"),
     * @OA\Property(property="description", type="string", format="string", example="description"),
     * @OA\Property(property="accreditation_start_date", type="string", format="string", example="accreditation_start_date"),
     * @OA\Property(property="accreditation_expiry_date", type="string", format="string", example="accreditation_expiry_date"),
     * @OA\Property(property="logo", type="string", format="string", example="logo"),

     *
     * ),
     * ),
     * @OA\Response(
     * response=200,
     * description="Successful operation",
     * @OA\JsonContent(),
     * ),
     * @OA\Response(
     * response=401,
     * description="Unauthenticated",
     * @OA\JsonContent(),
     * ),
     * @OA\Response(
     * response=422,
     * description="Unprocesseble Content",
     * @OA\JsonContent(),
     * ),
     * @OA\Response(
     * response=403,
     * description="Forbidden",
     * @OA\JsonContent()
     * ),
     * * @OA\Response(
     * response=400,
     * description="Bad Request",
     * *@OA\JsonContent()
     * ),
     * @OA\Response(
     * response=404,
     * description="not found",
     * *@OA\JsonContent()
     * )
     * )
     * )
     */

    public function updateAccreditation(AccreditationUpdateRequest $request)
    {
        DB::beginTransaction();
        try {
            $this->storeActivity($request, "DUMMY activity", "DUMMY description");


            $request_data = $request->validated();

            $accreditation_query_params = [
                "id" => $request_data["id"],
            ];

            $accreditation =
                Accreditation::where($accreditation_query_params)->first();

            if ($accreditation) {

                $accreditation->fill($request_data);
                $accreditation->save();

            } else {
                return response()->json([
                    "message" => "something went wrong."
                ], 500);
            }



            DB::commit();
            return response($accreditation, 201);
        } catch (Exception $e) {
            DB::rollBack();
            return $this->sendError($e, 500, $request);
        }
    }

    /**
     *
     * @OA\Put(
     * path="/v1.0/accreditations/toggle-active",
     * operationId="toggleActiveAccreditation",
     * tags={"accreditations"},
     * security={
     * {"bearerAuth": {}}
     * },
     * summary="This method is to toggle accreditations",
     * description="This method is to toggle accreditations",
     *
     * @OA\RequestBody(
     * required=true,
     * @OA\JsonContent(


     *
     * ),
     * ),
     * @OA\Response(
     * response=200,
     * description="Successful operation",
     * @OA\JsonContent(),
     * ),
     * @OA\Response(
     * response=401,
     * description="Unauthenticated",
     * @OA\JsonContent(),
     * ),
     * @OA\Response(
     * response=422,
     * description="Unprocesseble Content",
     * @OA\JsonContent(),
     * ),
     * @OA\Response(
     * response=403,
     * description="Forbidden",
     * @OA\JsonContent()
     * ),
     * * @OA\Response(
     * response=400,
     * description="Bad Request",
     * *@OA\JsonContent()
     * ),
     * @OA\Response(
     * response=404,
     * description="not found",
     * *@OA\JsonContent()
     * )
     * )
     * )
     */

    public function toggleActiveAccreditation(GetIdRequest $request)
    {

        try {

            $this->storeActivity($request, "DUMMY activity", "DUMMY description");


            $request_data = $request->validated();

            $accreditation = Accreditation::where([
                "id" => $request_data["id"],
            ])
                ->first();
            if (!$accreditation) {

                return response()->json([
                    "message" => "no data found"
                ], 404);
            }

            $accreditation->update([
                'is_active' => !$accreditation->is_active
            ]);




            return response()->json(['message' => 'accreditation status updated successfully'], 200);
        } catch (Exception $e) {
            error_log($e->getMessage());
            return $this->sendError($e, 500, $request);
        }
    }



    public function query_filters($query)
    {



        return $query->where('accreditations.created_by', auth()->user()->id)

            ->when(request()->filled("name"), function ($query) {
                return $query->where(
                    'accreditations.name',
                    request()->input("name")
                );
            })
            ->when(request()->filled("description"), function ($query) {
                return $query->where(
                    'accreditations.description',
                    request()->input("description")
                );
            })
            ->when(request()->filled("start_accreditation_start_date"), function ($query) {
                return $query->whereDate(
                    'accreditations.accreditation_start_date',
                    ">=",
                    request()->input("start_accreditation_start_date")
                );
            })
            ->when(request()->filled("end_accreditation_start_date"), function ($query) {
                return $query->whereDate('accreditations.accreditation_start_date', "<=", request()->input("end_accreditation_start_date"));
            })
            ->when(request()->filled("start_accreditation_expiry_date"), function ($query) {
                return $query->whereDate(
                    'accreditations.accreditation_expiry_date',
                    ">=",
                    request()->input("start_accreditation_expiry_date")
                );
            })
            ->when(request()->filled("end_accreditation_expiry_date"), function ($query) {
                return $query->whereDate('accreditations.accreditation_expiry_date', "<=", request()->input("end_accreditation_expiry_date"));
            })
            ->when(request()->filled("logo"), function ($query) {
                return $query->where(
                    'accreditations.logo',
                    request()->input("logo")
                );
            })


            ->when(request()->filled("search_key"), function ($query) {
                return $query->where(function ($query) {
                    $term = request()->input("search_key");
                    $query

                        ->orWhere("accreditations.name", "like", "%" . $term . "%")
                        ->where("accreditations.description", "like", "%" . $term . "%")
                        ->orWhere("accreditations.logo", "like", "%" . $term . "%")

                    ;
                });
            })


            ->when(request()->filled("start_date"), function ($query) {
                return $query->whereDate('accreditations.created_at', ">=", request()->input("start_date"));
            })
            ->when(request()->filled("end_date"), function ($query) {
                return $query->whereDate('accreditations.created_at', "<=", request()->input("end_date"));
            })
             // 🔹 EXPIRATION FILTERS (same logic as tenancy agreement)
        ->when(
            request()->filled("is_accreditation_expired") ||
            request()->filled("accreditation_expired_in"),
            function ($query) {
                if (request()->filled('is_accreditation_expired')) {
                    $query->whereDate('accreditations.accreditation_expiry_date', '<', Carbon::today());
                }

                if (request()->filled('accreditation_expired_in')) {
                    $expiry_days = request()->input('accreditation_expired_in');
                    if (is_numeric($expiry_days) && $expiry_days > 0) {
                        $query->whereDate('accreditations.accreditation_expiry_date', '>', Carbon::today())
                            ->whereDate('accreditations.accreditation_expiry_date', '<=', Carbon::today()->addDays($expiry_days));
                    }
                }
            }
        )

            ;
    }



    /**
     *
     * @OA\Get(
     * path="/v1.0/accreditations",
     * operationId="getAccreditations",
     * tags={"accreditations"},
     * security={
     * {"bearerAuth": {}}
     * },

     * @OA\Parameter(
     * name="name",
     * in="query",
     * description="name",
     * required=false,
     * example=""
     * ),
     * @OA\Parameter(
     * name="description",
     * in="query",
     * description="description",
     * required=false,
     * example=""
     * ),
     *
     *   * @OA\Parameter(
     * name="is_accreditation_expired",
     * in="query",
     * description="is_accreditation_expired",
     * required=false,
     * example=""
     * ),
     *  *   * @OA\Parameter(
     * name="accreditation_expired_in",
     * in="query",
     * description="accreditation_expired_in",
     * required=false,
     * example=""
     * ),
     *
     * @OA\Parameter(
     * name="start_accreditation_start_date",
     * in="query",
     * description="start_accreditation_start_date",
     * required=false,
     * example=""
     * ),
     * @OA\Parameter(
     * name="end_accreditation_start_date",
     * in="query",
     * description="end_accreditation_start_date",
     * required=false,
     * example=""
     * ),
     * @OA\Parameter(
     * name="start_accreditation_expiry_date",
     * in="query",
     * description="start_accreditation_expiry_date",
     * required=false,
     * example=""
     * ),
     * @OA\Parameter(
     * name="end_accreditation_expiry_date",
     * in="query",
     * description="end_accreditation_expiry_date",
     * required=false,
     * example=""
     * ),
     * @OA\Parameter(
     * name="logo",
     * in="query",
     * description="logo",
     * required=false,
     * example=""
     * ),

     * @OA\Parameter(
     * name="per_page",
     * in="query",
     * description="per_page",
     * required=false,
     * example=""
     * ),

     * @OA\Parameter(
     * name="is_active",
     * in="query",
     * description="is_active",
     * required=false,
     * example=""
     * ),
     * @OA\Parameter(
     * name="start_date",
     * in="query",
     * description="start_date",
     * required=false,
     * example=""
     * ),
     * * @OA\Parameter(
     * name="end_date",
     * in="query",
     * description="end_date",
     * required=false,
     * example=""
     * ),
     * * @OA\Parameter(
     * name="search_key",
     * in="query",
     * description="search_key",
     * required=false,
     * example=""
     * ),
     * * @OA\Parameter(
     * name="order_by",
     * in="query",
     * description="order_by",
     * required=false,
     * example="ASC"
     * ),
     * * @OA\Parameter(
     * name="id",
     * in="query",
     * description="id",
     * required=false,
     * example=""
     * ),




     * summary="This method is to get accreditations ",
     * description="This method is to get accreditations ",
     *

     * @OA\Response(
     * response=200,
     * description="Successful operation",
     * @OA\JsonContent(),
     * ),
     * @OA\Response(
     * response=401,
     * description="Unauthenticated",
     * @OA\JsonContent(),
     * ),
     * @OA\Response(
     * response=422,
     * description="Unprocesseble Content",
     * @OA\JsonContent(),
     * ),
     * @OA\Response(
     * response=403,
     * description="Forbidden",
     * @OA\JsonContent()
     * ),
     * * @OA\Response(
     * response=400,
     * description="Bad Request",
     * *@OA\JsonContent()
     * ),
     * @OA\Response(
     * response=404,
     * description="not found",
     * *@OA\JsonContent()
     * )
     * )
     * )
     */

    public function getAccreditations(Request $request)
    {
        try {
            $this->storeActivity($request, "DUMMY activity", "DUMMY description");



            $query = Accreditation::query();
            $query = $this->query_filters($query);
            $accreditations = $this->retrieveData($query, "id", "accreditations");




            return response()->json($accreditations, 200);
        } catch (Exception $e) {

            return $this->sendError($e, 500, $request);
        }
    }
    /**
     *
     * @OA\Delete(
     * path="/v1.0/accreditations/{ids}",
     * operationId="deleteAccreditationsByIds",
     * tags={"accreditations"},
     * security={
     * {"bearerAuth": {}}
     * },
     * @OA\Parameter(
     * name="ids",
     * in="path",
     * description="ids",
     * required=true,
     * example="1,2,3"
     * ),
     * summary="This method is to delete accreditation by id",
     * description="This method is to delete accreditation by id",
     *

     * @OA\Response(
     * response=200,
     * description="Successful operation",
     * @OA\JsonContent(),
     * ),
     * @OA\Response(
     * response=401,
     * description="Unauthenticated",
     * @OA\JsonContent(),
     * ),
     * @OA\Response(
     * response=422,
     * description="Unprocesseble Content",
     * @OA\JsonContent(),
     * ),
     * @OA\Response(
     * response=403,
     * description="Forbidden",
     * @OA\JsonContent()
     * ),
     * * @OA\Response(
     * response=400,
     * description="Bad Request",
     * *@OA\JsonContent()
     * ),
     * @OA\Response(
     * response=404,
     * description="not found",
     * *@OA\JsonContent()
     * )
     * )
     * )
     */

    public function deleteAccreditationsByIds(Request $request, $ids)
    {

        try {
            $this->storeActivity($request, "DUMMY activity", "DUMMY description");



            $idsArray = explode(',', $ids);
            $existingIds = Accreditation::whereIn('id', $idsArray)
                ->where('accreditations.created_by', auth()->user()->id)

                ->select('id')
                ->get()
                ->pluck('id')
                ->toArray();
            $nonExistingIds = array_diff($idsArray, $existingIds);

            if (!empty($nonExistingIds)) {

                return response()->json([
                    "message" => "Some or all of the specified data do not exist."
                ], 404);
            }





            Accreditation::destroy($existingIds);


            return response()->json(["message" => "data deleted sussfully", "deleted_ids" => $existingIds], 200);
        } catch (Exception $e) {

            return $this->sendError($e, 500, $request);
        }
    }
}
