<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PropertyUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'id' => "required|numeric|exists:properties,id",
            'name' => "nullable|string",
            'image' => "nullable|string",
            'address' => "nullable|string",
            'country' => "required|string",
            'city' => "required|string",
            'postcode' => "required|string",
            'town' => "nullable|string",
            'lat' => 'nullable|numeric',
            'long' => 'nullable|numeric',
            'type' => "required|string",
            'reference_no' => 'required|string|max:255',
            'current_status' => 'nullable|string|in:available,occupied,reserved,under_maintenance,off_market,eviction,notice_given,under_offer,sold,blocked',
            'is_active' => 'nullable|boolean',



            'tenant_ids' => 'nullable|array',
            'tenant_ids.*' => 'nullable|exists:tenants,id',

            'landlord_ids' => 'present|array',
            'landlord_ids.*' => 'numeric|exists:landlords,id',

            //
            "min_price" => "nullable|numeric",
            "max_price" => "nullable|numeric|gt:min_price",
        ];
    }
}
