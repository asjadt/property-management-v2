<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tag extends Model
{
    use HasFactory;

    protected $fillable = [
        'tag',
        "is_default",
        "garage_id",
    ];
    protected $hidden = [
        'created_at',
        'updated_at',

    ];
}
