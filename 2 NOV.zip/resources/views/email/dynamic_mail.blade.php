{!! $html_content !!}

